# ReplayMod Video + Audio

by Sumitberry

A Fabric addon for Replay Mod that captures audio during renders and merges it straight into your video.

## Features

- Audio merges straight into your video — no separate file, no extra syncing.
- Pick your format: AAC, MP3, or Opus.
- Control your quality with bitrates from 128 to 320 kbps — 128, 192, 256, 320.

## Versions

This is the main source code — it is not tied to one Minecraft version. The shared code lives in `src/main`, and every Minecraft version has its own build config in `versions/`. The jars for Minecraft 1.21 to 26.x published on Modrinth are all built from this same code.

## Requirements

- Fabric Loader
- Replay Mod (matching the Minecraft version)

## License

GPL-3.0

Copyright (C) 2026 Sumitberry
