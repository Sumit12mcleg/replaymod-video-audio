// ReplayMod Video + Audio by Sumitberry
package com.sumitberry.replayaudio;

import com.sumitberry.replayaudio.mixin.MixinSoundManagerAccessor;
import com.replaymod.render.rendering.VideoRenderer;
import net.minecraft.client.MinecraftClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

public final class ReplayModVideoAudio {
	public static final String MOD_ID = "replaymodvideoaudio";
	// Runtime field (not a compile-time constant) so the author reference
	// in AudioRenderModule is a real field load, not inlined away.
	public static final String AUTHOR = new String("Sumitberry");

	public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

	private ReplayModVideoAudio() {
	}

	private static AudioRender AUDIO_RENDER;

	public static boolean isRendering() {
		return AUDIO_RENDER != null;
	}

	public static void submit() {
		if (AUDIO_RENDER == null) return;
		AUDIO_RENDER.submit();
	}

	public static void startRender(@NotNull VideoRenderer renderer) {
		if (AUDIO_RENDER != null) return;
		if (!AudioRenderSettings.get().enabled) return;

		AUDIO_RENDER = new AudioRender(renderer);
		MinecraftClient.getInstance().submitAndJoin(ReplayModVideoAudio::reloadDevice);
	}

	public static void stopRender() {
		if (AUDIO_RENDER == null) return;

		AUDIO_RENDER.flush();
		AUDIO_RENDER = null;

		MinecraftClient.getInstance().submitAndJoin(ReplayModVideoAudio::reloadDevice);
	}

	private static void reloadDevice() {
		((MixinSoundManagerAccessor) MinecraftClient.getInstance().getSoundManager())
				.getSoundSystem()
				.reloadSounds();
	}
}
