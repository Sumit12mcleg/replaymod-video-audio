// ReplayMod Video + Audio by Sumitberry
package com.sumitberry.replayaudio;

import com.replaymod.core.Module;
import com.replaymod.lib.de.johni0702.minecraft.gui.utils.EventRegistrations;
import com.replaymod.render.events.ReplayRenderCallback;

public class AudioRenderModule extends EventRegistrations implements Module {

    @Override
    public void initClient() {
        ReplayModVideoAudio.LOGGER.info("ReplayMod Video + Audio by {}", ReplayModVideoAudio.AUTHOR);
        on(ReplayRenderCallback.Pre.EVENT, ReplayModVideoAudio::startRender);
        register();
    }
}
