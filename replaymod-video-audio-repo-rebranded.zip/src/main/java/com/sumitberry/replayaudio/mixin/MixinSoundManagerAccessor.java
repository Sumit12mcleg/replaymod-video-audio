// ReplayMod Video + Audio by Sumitberry
package com.sumitberry.replayaudio.mixin;

import net.minecraft.client.sound.SoundManager;
import net.minecraft.client.sound.SoundSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SoundManager.class)
public interface MixinSoundManagerAccessor {

    @Accessor("field_5590")
    SoundSystem getSoundSystem();
}
