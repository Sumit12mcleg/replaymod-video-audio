// ReplayMod Video + Audio by Sumitberry
package com.sumitberry.replayaudio.mixin;

import com.sumitberry.replayaudio.AudioRenderSettings;
import com.sumitberry.replayaudio.ReplayModVideoAudio;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.replaymod.render.rendering.VideoRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.option.SimpleOption;
/*import net.minecraft.client.Options;
import net.minecraft.sounds.SoundSource;
*/

@Mixin(VideoRenderer.class)
public class MixinVideoRenderer {
    @WrapOperation(
            method = "setup",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/SimpleOption;setValue(Ljava/lang/Object;)V")
    )
    private void setSoundVolume(SimpleOption<?> instance, Object object, Operation<Void> original) {
        if (AudioRenderSettings.get().enabled) return;
        original.call(instance, object);
    }
    /*@WrapOperation(
            method = "setup",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Options;setSoundCategoryVolume(Lnet/minecraft/sounds/SoundSource;F)V")
    )
    private void setSoundVolume(Options instance, SoundSource soundSource, float v, Operation<Void> original) {
        if (AudioRenderSettings.get().enabled) return;
        original.call(instance, soundSource, v);
    }*/

    @Inject(
            method = "finish",
            at = @At(value = "HEAD")
    )
    private void onFinish(CallbackInfo ci) {
        ReplayModVideoAudio.stopRender();
    }
}
