# Changelog

## 1.0+1.21

- Bitrate (kbps) option added: 128, 192, 256, 320.
- Audio merges straight into the video.
- Format options: AAC, MP3, Opus.
- Minecraft 1.21, Fabric.
