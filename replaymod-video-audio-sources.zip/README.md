# ReplayMod Video + Audio

A Fabric addon for Replay Mod that captures audio during renders and merges it straight into your video.

## Features

- Audio merges straight into your video — no separate file, no extra syncing.
- Pick your format: AAC, MP3, or Opus.
- Control your quality with bitrates from 128 to 320 kbps — 128, 192, 256, 320.

## Requirements

- Minecraft 1.21
- Fabric Loader
- Replay Mod 2.6.23

## License

LGPL-3.0
