package com.apehum.replayaudio.mixin;

import com.apehum.replayaudio.ReplayModAudioRender;
import com.replaymod.lib.de.johni0702.minecraft.gui.element.AbstractGuiButton;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractGuiButton.class)
public class MixinGuiButton {
    @Inject(method = "playClickSound(Lnet/minecraft/client/MinecraftClient;)V", at = @At("HEAD"), cancellable = true)
    private static void playClickSound(MinecraftClient mc, CallbackInfo ci) {
        if (ReplayModAudioRender.isRendering()) {
            ci.cancel();
        }
    }
}
